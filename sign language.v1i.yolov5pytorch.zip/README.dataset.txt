# sign language > 2024-03-18 10:40am
https://universe.roboflow.com/sign-language-gnbah/sign-language-st9ig

Provided by a Roboflow user
License: CC BY 4.0

